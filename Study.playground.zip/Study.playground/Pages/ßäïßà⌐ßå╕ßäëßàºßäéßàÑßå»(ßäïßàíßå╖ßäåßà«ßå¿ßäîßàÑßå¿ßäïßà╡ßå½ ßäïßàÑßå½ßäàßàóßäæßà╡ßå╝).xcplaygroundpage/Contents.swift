import Foundation
import UIKit
//암묵적인 언래핑(implicitly unwrapped) - 옵셔널이 항상 유효한 값을 가진 경우. 자료형 뒤에 !
    //강제 언래핑이나 옵셔널 바인딩을 하지 않아도 값을 사용 가능

//Int? , Int! - 두 가지 옵셔널
    //Int?
let x : Int? = 1
let y : Int = x!  //강제 언래핑(!)
let z = x
print(x, y, z)  //Optional(1) 1 Optional(1)
    //Int!
let a : Int! = 1  //암묵적인 언래핑
let b : Int = a   //옵셔널로 사용되지 않으면 자동으로 언래핑함
let c : Int = a!  //옵셔널이지만 강제 언래핑 사용
let d = a         //옵셔널로 사용 될 수 있으므로 옵셔널형(자료형 선택 안되있으므로)
let e = a + 1     //Optional(1) + 1은 성립이 되지 않으므로 자동으로 풀어준다.
print(a, b, c ,d, e)  //Optional(1) 1 1 Optional(1) 2

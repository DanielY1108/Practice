import Foundation

//표준 자료형들(Int, Double...)은 다 구조체로 되어있다.
//스위프트 프로그램에서 숫자를 저장
var mynum = 10  //mynum라는 이름의 변수를 생성했으며, 숫자 10을 할당
//var mynum : Int = 10  컴파일러가 타입 추론(type inference) 하기 때문에 여기서 Int 생략가능
    //자료형들은 첫 글자가 이와 같이 대문자 시작(Bool, Character, Int, Float, Double, String, Void)
var x : Int  //위와 같은 말
x = 10

print(mynum)
print(x)

//자료형의 종류 나오게 하기
var y : String = "Hi"
print(type(of: mynum))  //Int
print(type(of: y))  //String

//정수 데이터 타입 : Int
print("출력하고 싶은 변수나 상수는 \(x)를 사용")  //여러가지 다른 값과 같이 출력할때는 ""를 사용해서 문자열 형식으로 해서 출력해줘 된다. "\(변수 or 상수)"를 넣으면 출력가능

//부동 소수점 데이터 타입 : Double, Float
  //Double형이 기본 타입이며
var myWeight = 67.5  //초기값이 "67.5" 타입 추론을 해서 Double 형으로 인식
print(type(of: myWeight))  //Double

//부울 데이터 타입 : Bool
    //참 or 거짓 (1 or 0)조건을 처리하는 데이터 타입
var redAreRed = true  //초기값 true 가 있으므로 :Bool 생략 가능, var redAreRed : Bool = true

//문자 데이터 타입 : Character
    //문자, 숫자, 문장 부호, 심볼 같은 유니코드 문자 '하나'를 저장
var myChar = "1"  //이와같이 쓰면 String으로 인식, 꼭 앞에 자료형을 넣어줘야 된다.
var myChar1 : Character = "1"
print(type(of: myChar))  //String
print(type(of: myChar1))  //Character

//문자열 데이터 타입 : String
    //단어나 문장을 구성하는 일련의 문자
    //문자열 보간을 사용하여 문자열과 변수, 상수, 표현식, 함수 호출 가능
var userName : String = "Yang"
var age : Int = 32
var messege : String = "\(userName)의 나이는 \(age)입니다."
print(messege)  //Yang의 나이는 32입니다.

//특수 문자
    // \n - 개행(열 아래로)
    // \r - 캐리지 리턴(열 시작으로)
    // \"  , \' , \\
print("개행\n(열 아래로), \", \', \\")







import Foundation

//자식과 부모의 상속 관계에서 함수가 맘에 안들때 똑 같은 이름, 매개변수, 리턴형을 갖는 함수를 똑같이 만든다.(기능만 다름)
//부모와 자식의 display()라는 메서드가 2개(자식,부모)이다. 호출 시 자식쪽의 메서드를 우선적으로 하기위해 func 앞에 override 키워드를 씀
class Man {
    var age : Int = 0
    var weight : Double = 0
    func display() {
        print("나이 = \(age), 몸무게 = \(weight)")
    }
    init(age : Int ,weight : Double) {
        self.age = age
        self.weight = weight
    }
}
class Student : Man {
    var name : String = "Jin"
    override func display() {  //override키워드는 자식 함수 우선적으로 호출
        print("이름 = \(name), 나이 = \(age), 몸무게 = \(weight)")
    }
    init(age : Int ,weight : Double, name: String) {
        super.init(age: age, weight: weight)
        self.name = name
    }
}
var yang = Student(age: 20, weight: 30, name: "JINSEOK")
yang.display()

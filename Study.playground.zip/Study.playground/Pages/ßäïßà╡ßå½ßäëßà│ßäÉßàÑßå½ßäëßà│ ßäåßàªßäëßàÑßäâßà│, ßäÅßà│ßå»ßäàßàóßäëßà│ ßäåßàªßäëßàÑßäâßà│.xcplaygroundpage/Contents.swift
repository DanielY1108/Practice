import Foundation

    //Method - 메서드는 함수(func)다 - class내에서 함수를 생성하면 메서드라고 한다.
//프로퍼티를 처리하는 동작, 인스턴스 메서드 or 클래스(타입) 메서드가 있고 인스턴스 메서드는 인스턴스에서 동작
class Man2 {
    var age : Int = 1
    var weight : Double = 3.5
    func display(){     //인스턴스 메서드
        print("나이 =\(age), 몸무게는 =\(weight)")
    }
}

//인스턴스(객체)를 만들고 메서드와 프로퍼티 접근
class Man {
    var age : Int = 2               //저장 프로퍼티, 초기값이 필요하다
    var weight : Double = 3.5       //저장 프로퍼티
    func display() {
        print("나이 = \(age), 몸무게 = \(weight)")       //인스턴스 메서드
    }
    class func cM() {                           //class 키워드로 만든 클래스 메서드는 자식 클래스에서 override 가능함
        print("cM은 클래스 메서드 입니다")            //override(부모와 자식간의 관계에서 맘에 안들면 자식 값을 우선시 하게 함)
    }
    static func scM() {                         //상속 고려하지 않으면 static 사용
        print("scM은 클래스 메서드(static)")
    }
}
//var 인스턴스(객체)명 : 클래스명 = 클래스명()       여기서의 클래스명 다음 괄호는 보이지 않는 디폴스 생성자(default initializer)를 호출해야 된다.
//var 인스턴스(객체)명 = 클래스명()                생략 가능

//var kim : Man = Man()     //인스턴스(객체)를 만들때는 클래스의 생성자(init) 호출하기 위해 "()"(함수를 호출한다는 말)써야 된다.
                            //기본적으로 클래스를 만들면 디폴트 생성자(default initializer)가 자동으로 생성된다.
var kim = Man()             //생략 가능
print(kim.age)              //인스턴스가 프로퍼티 접근할때 "." 사용.  (인스턴스.프로퍼티)

kim.display()               //인스턴스(kim) 메서드 인스턴스가 호출.  (인스턴스.인스턴스 메서드)
//kim.cM()                  // 실행이 안된다. 이유는 이 클래스 메서드는 클래스 자체로 실행.
Man.cM()                    //클래스 메서드는 클래스(man)가 호출
Man.scM()


//discardableResult - 폐기 가능한 결과

@discardableResult
func a() -> Int {
    return 10
}
a()


var aa = 5
var b = "7"
var intStr = Int(b)
print(aa + intStr!, separator: "" )


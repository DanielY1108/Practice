import Foundation

//타입 검사(is)
    //지정된 객체가 클래스의 인스턴스인지 검사
    //인스턴스가 해당 클래스인가? 인스턴스 is 클래스
class A {}
var a : A = A()
if a is A {
  print("yes")
}

//any와 anyObject
    //AnyObject (protocol = 클래스의 최상위 개념)
    //어떤 클래스의 인스턴스(객체)도 저장 가능
    //클래스만 허용하며 구조체나 열거형은 허용하지 않음

    //Any - 포괄적인 개념, 모든 타입을 포괄할 수 있는 자료형이다.(최상위 자료형)
    //클래스, 구조체, 열거형, 함수타입도 가능

//연산자
    //기본 할당 연산자
    //"=" 기준으로 왼쪽은 값이 할당 되는 변수나 상수, 오른쪽은 할당할 값(주로 산술식 or 논리식)
var x : Int?  // 옵셔널 Int로 선언
var y = 10  // 일반 Int 선언
x = 10  // 값을 x에 할당함 위에 옵셔널이니까 Optional(10)
x = x! + y  // x!+y = 20 이 결과를 x에 할당함 Optional(20)
x = y  // y의 값을 x에 할당함 Optional(10)

    //복합 할당 연산자
//x = x + y,  변수가 같으면 뒤에 x 생략하고 +가 앞으로 이동
//x += y,  변수 x 값과 변수 y값을 더하고 그 결과를 변수 x에 저장

    //증가 연산자, 감소 연산자
//x = x + 1
//x += 1
    
    //범위 연산자
//닫힌 범위 연산자 - x...y, x부터 시작 y까지
//반 열림 범위 연산자 - x..<y, x부터 시작 y가 포함되지 않는 수
//One-sided ranges
let names = ["A", "B", "C", "D"]  //배열 0, 1, 2, 3 이런식으로 0부터 시작
for name in names[2...] {  //[...2] = A, B, C,  [..<2] = A, B
    print(name)
}  //C
   //D

    //삼항 연산자 ?:
//변수 선언 및 if else 을 한줄로 요약해서 쓰는 방법
//참고 변수가 다르면 안된다 ex. 문자열 & 문자 배열 , Int & Float, 문자& Int 등등
var X = 1
var Y = 2
print("Largest Number is \(X > Y ? X : Y)")  //Largest Number is 2
//[조건] ? [참 표현식] : [거짓 표현식]
//조건이 오고 참이면 ? 다음 값이 나오고 거짓이면 :(콜론) 뒤의 값이 나온다.

    //Nil-Coalescing Operator (Nil 합병연산자) : ??
//옵셔널변수 ?? nil 일 때 할당되는 값
//옵셔널 변수의 값이 nil 이면 ?? 다음 값이 할당된다
let defaultAge = 0
var age : Int?  //옵셔널 값이 nil이면 defaultAge 할당 
age = 32  //Optional(32), 
var myAge = age ?? defaultAge
print(myAge)  //32, 자동으로 옵셔널을 풀어준다.



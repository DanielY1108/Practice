import Foundation

//공통점
//  프로퍼티와 메서드를 정의할 수 있다.
//  []를 사용해 점자(subscript) 문법으로 내부의 값을 액세스할 수 있는 첨자를 정의할 수 있다.
//  초기 상태 설정을 위한 init()을 정의할 수 있다.
//  extension을 통해 새로운 기능 추가 가능
//  프로토콜을 사용 하능

//class이 더 갖는 특징
//  상속이 가능하다.
//  타입 캐스팅(is, as)을 통해 실행 시점에 클래스 인스턴스의 타입을 해석하고 검사할 수 있다.
//  deinit함수를 사용해 사용한 자원을 반환할 수 있다.(소멸자)
//  참조 카운팅을 통해 한 클래스 인스턴스를 여러 곳에서 참조(사용)할 수 있다.

//구조체
struct Human {
    var age : Int = 1
}
var kim = Human()
var lee = kim  //kim, lee 초기값만 같다.(입력한 값만 변경됨)
print(kim.age, lee.age)  //1 1
lee.age = 20
print(kim.age, lee.age)  //1 20
kim.age = 40
print(kim.age, lee.age)  //40 20
//값 타입은 복사할 때 새로운 데이터가 하나 더 생긴다.

//클래스
class Human1 {
    var age : Int = 1
}
var kim1 = Human1()
var lee1 = kim1  //kim의 주소를 lee가 갖고 있다.(Reference type)참조 타입, kim이 바뀌면 lee도 바뀐다 주소가 같아서
print(kim1.age, lee1.age)  //1 1
lee1.age = 20
print(kim1.age, lee1.age)  //20 20
kim1.age = 40
print(kim1.age, lee1.age)  //40 40
//참조 타입은 복사할 때 주소를 복사해서 한 데이터의 reference가 2개 생김

//ex.
struct Resolution {
    var width = 0
    var height = 0
}
class VideoMode {
    var resolution = Resolution()
    var frameRate = 0
    var name: String?
}
var hd = Resolution(width: 1920, height: 1080)  //memberwise initioalizer(구조제는 자동으로 만들어진다. init만들 필요 없다.)
var highDef = hd  //구조체는 값타입
//구조체
print(hd.width, highDef.width)
hd.width = 1024
print(hd.width, highDef.width)
//클래스
var xMonitor = VideoMode()
xMonitor.resolution = hd
xMonitor.name = "Apple"
xMonitor.frameRate = 60
print(xMonitor.frameRate)

var yMoonitor = xMonitor  //참조란 계속 따라서
yMoonitor.frameRate = 30
print(yMoonitor.frameRate)
print(xMonitor.frameRate)

//call by value - 기본 자료형(Int, String, Array, Dictionary 등)은 구조체로 만들어져있다. enum
//call by reference - class

//언제 클래스,구조체를 쓰나?
    //구조체는 간단한 데이터 값들을 한데 묶어서 사용하는 경우
    //전체 덩어리 크기가 작은 경우, 복사를 통해 전달해도 좋은 경우
    //멀티 쓰레드 환경이라면 구조체가 더 안전하다.
    //구조체는 기존 타입의 특성을 상속할 필요가 없다.(너비,높이를 표현하는 기하학적 모양을 처리, 좌표 시스템의 각좌표 등)

//값 타입
    //1.변수를 할당하면 스택에 값이 쌓인다. 2. 복사본을 변경하더라도 원본이 영향을 받지 않는다.

//레퍼런스 타입
    //1.스택에는 포인터만 할당되고, 실제 데이터는 힙에 할당된다. 2.복사본과 원본이 모두 같은 값을 갖는다. 즉 복사본을 변경하더라도 원본이 영향을 받는다.

//힙 영역
    //프로그래머가 할당/해제 하는 메모리 영역, 동적 할당(힙에 메모리를 할당가능하면)
    //사용하고 난 후에는 반드시 메모리 해제를 해줘야 한다. 그렇지 않으면 'memory leak'이 발생
    //code, data, stack 중 유일하게 '런타임 시' 결정되기 때문에 데이터 크기가 확실하지 않을 때 사용.

//스택 영역
    //함수 호출 시 함수의 지역변수, 매개변수, 리턴 값 등등이 저장되고, 함수가 종료되면 저장된 메모리도 해제된다.
    //컴파일 타임에 결정 되기 때문에 무한히 할당할 수 없다.
    //프로그램이 자동으로 사용하는 임시 메모리 영역
    //스택은 자료구조에서 "LIFO"(last in, first out) 데이터 구조이고(먼저 생성된 변수가 가장 나중에 해제됨) CPU에 의해 관리되고 최적화 돼서 속도가 매우 빠름!!

//https://shark-sea.kr/

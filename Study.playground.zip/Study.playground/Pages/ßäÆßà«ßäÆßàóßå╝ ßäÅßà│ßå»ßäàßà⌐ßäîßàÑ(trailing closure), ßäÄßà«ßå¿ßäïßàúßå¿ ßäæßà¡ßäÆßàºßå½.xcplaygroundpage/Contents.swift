import UIKit

//후행 클로저 - 클로저 함수의 마지막 argument(인수)라면 마지막 매개변수 이름(handler : )을 생략한 후 함수 소괄호 외부에 클로저를 구현

//question 함수 -> 클로저 표현식 -> 후행 클로저 

    //함수 -> 클로저 표현식
let add = {(num1 : Int , num2 : Int) -> Int in  //매개변수 앞에 "{" 넣어주고 기존 있던 "{" 자리에 "in" 을 입력.
    return num1 + num2
}
let multiply = {(num1 : Int , num2 : Int) -> Int in
    return num1 * num2
}
var result = add(10, 20)    //호출시 그냥 매개변수 값만 넘겨주면 된다. (상수를 함수처럼 호출, 하지만 함수는 아니다)
print(result)
result = multiply(10,  20)  //변수(var) 사용했으니까 result만 써도 된다.
print(result)

func math(x : Int, y : Int, cal : (Int, Int) -> Int) -> Int {
    return cal(x, y)
}
//func math(x : Int, y : Int) {(Int, Int) -> Int) in
//    return cal(x, y)
//}

result = math(x: 10, y: 20, cal: add)
print(result)
result = math(x: 10, y: 20, cal: multiply)
print(result)

    //클로저
result = math(x: 10, y: 20, cal: {(num1 : Int , num2 : Int) -> Int in  //위의 'add' 소스를 'cal'에다 그대로 갖고옴
    return num1 + num2
})
print(result)
result = math(x: 10, y: 20, cal: {(num1 : Int , num2 : Int) in  //리턴형 매개변수 생략 가능, 반환타입 생략 가능( -> Int)
    return num1 + num2
})
print(result)
result = math(x: 10, y: 20, cal: {  //클로저 상에서 매개변수 이름이 필요없다면 생략하고 단축인자(Shorthand argument name)사용
    return $0 + $1  //클로저의 매개변수 단축인자는 순서대로 $0,$1,$2...
})
print(result)

result = math(x: 10, y: 20, cal: {$0 + $1})   //클로저에 return을 쓰지 않아도, 암시적로 마지막 줄이 반환값으로 취급(return 생략)
print(result)

    //후행 클로저(trailing closure) - 마지막 인자에 클로저를 쓸 때
result = math(x: 10, y: 20) {(num1 : Int , num2 : Int) -> Int in  //후행 클로저는 이런식으로 만들 수 있다. 매개변수 이름 부분(cal:) 제거
    return num1 + num2  //클로저 함수의 마지막 argument(인수)라면 마지막 매개변수 이름(handler : )을 생략한 후 함수 소괄호 외부에 클로저를 구현
}
print(result)
result = math(x: 10, y: 20) {(num1 : Int , num2 : Int) in  //클로저와 같이 후행 클로저 또한 리턴형 매개변수(-> Int) 생략 가능, 반환타입 생략 가능
    return num1 + num2
}
print(result)
result = math(x: 10, y: 20) {  //위와 같이 후행 클로저에서도 단축인자 사용가능
    return $0 + $1
}
print(result)
result = math(x: 10, y: 20) {$0 + $1}  //또한 후행 클로저에서도 return을 쓰지 않아도, 암시적로 마지막 줄이 반환값으로 취급(return 생략)
print(result)

//소스를 굉장히 간단하게 만들 수 있지만, 과하게 사용하면 문장을 이해가 어려울 수 있다.

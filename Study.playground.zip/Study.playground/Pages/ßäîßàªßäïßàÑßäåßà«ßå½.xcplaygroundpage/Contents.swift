import Foundation

//for - in 반복문
    //for [반복문 안에서 사용할 변수명] in [매개변수] {
    //}
for i in 1...3 {
  print("\(i) 안녕")
}
for _ in 1...3 {
  print("안녕")
}  //언더바(_)로 참조체(i) 생략 가능

    //배열의 항목 접근
let names = ["Daniel", "Alex", "Mark", "Jack"]
for name in names {
    print(name)
}
//Daniel
//Alex
//Mark
//Jack

    //Dictionary의 항목 접근
//키와 밸류, 키와 밸류의 형식의 배열. key : value 형식
let numOfLeg = ["spider" : 8 , "ant" : 6 , "human" : 2]
for (animalName, legCount) in numOfLeg {  //animalName = 키 , legCount = 밸류
    print("\(animalName)s have \(legCount) leg")
}
//humans have 2 leg
//spiders have 8 leg
//ants have 6 leg

    //While 반복문
var myCount = 0
while myCount < 1000 {  //myCount < 1000 조건문, myCount가 1000 보다 크지 않을 때 까지 반복, 1000되는 시점에 반복문 종료
  myCount += 1  // 1씩 더한다.
}
print(myCount)  //1000

    //repeat - while 반복문
var i = 10
repeat {  //반복해라
 i = i - 1  // i 는 1씩 줄어 든다
 print(i)
} while (i > 3)  // i 가 3보다 크면 true, 정지

    //반복문에서 빠져나오기(break)
for n in 1...10 {  //1 부터 10까지 반복
  if n > 5 {  // n이 5보다 크면 true
    break  //정지해라
  }
  print(n)  // 1 2 3 4 5
}

    //continue문
//반복문에서 continue문 이후의 모든 코드를 건너뛰고 반복문 상단 시작 위치로 돌아감
for n in 1...10 {  //1 부터 10 까지 반복
  if n % 2 == 0 {  //짝수면
    continue  //건너뛰고 다시 시작
  }
   print(n)  // 1 3 5 7 9
}

    //if문
//실행 코드가 한줄이라도 있으면 {} 필수
//if <불리언 표현식> { 표현식이 참이면 실행 }
//else { 거짓이면 실행 }

    //guard문(조건식이 거짓이면 실행)
//guard <불리언 표현식> else {
//    표현식이 거짓일 결우에 실행될 코드
//}
//표현식이 참일 경우 실행 되는 코드
func multiplyByTen(value : Int?) {
    guard let number = value, number < 10 else {  //조건식이 거짓일 때 실행
        print("수가 10보다 크다.")
        return  //else 절에 속한 코드는 현재의 흐름을 빠져 나갈 수 있는 구문 (returne, break, continue, throw 구문)을 반드시 포함해야 함
    }
    print(number * 10)  //조건식이 참일 때 실행, 언래핑된 number 변수를 여기서도 사용가능. (if문은 사용 불가)
}
multiplyByTen(value: 5)  //50



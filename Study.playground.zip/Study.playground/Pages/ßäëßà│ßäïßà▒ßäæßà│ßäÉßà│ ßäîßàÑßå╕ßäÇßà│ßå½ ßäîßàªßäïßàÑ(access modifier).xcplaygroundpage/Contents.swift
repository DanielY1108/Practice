import Foundation

//access Modifier
//접근 속성(접근 수정자, 액세스 수정자, 액세스 지정자)는 클래스, 메서드, 멈버의 접근 가능성을 설정하는 객체 지향 언어의 키워드.
//구성 요서를 캡슐화 하는 데 사용
//접근 제어는 모듈이라는 말을 알아야 한다
//모듈은 코드 배포의 단일 유닛 - 앱, Framework(UIKit 등), 외부라이브러리

//open & public - 모듈의 모든 소스파일 내에서 사용할 뿐만 아니라 다른 모듈의 소스파일에서도 사용 가능.
//  두 접근자의 차이점은 open은 (클래스에서 사용)다른 모듈에서 override, 자식 클래스에서 상속가능, public은 다른 모듈에서 불가능 (클래스에서 불가)
//internal - 해당 모듈의 모든 소스파일 내에서 사용되지만, 해당 모듈 외부의 소스파일에서는 사용되지 않도록 한다.(기본 접근레밸로 아무선언 하지 않으면 Interner로 간주)
//fileprivate - 해상 소스파일 내에서만 사용가능
//private - 동일 블록 및 파일에서만 접근 가능 (선언된 괄호 {} 안에서만 사용가능)

//접근 제어 예
//open class var blue : UIColor { get }  //타입 프로퍼티
//open : 모듈 외부까지(클래스에만 사용) 접근 가능
//class : 클래스 프로퍼티(타입 프로퍼티)
//읽기 쓰기 가능한 프로퍼티는 정의 뒤에 {get set}
//읽기만 가능한 프로퍼티는 정의 뒤에 {get}

public class MyClass {  //public 모듈 외부에서도 접근 가능
    fileprivate var name : String = "Kim"  //현재 소스 파일 내에서만 사용 가능(같은 파일)
    private func play() {}  //현재 블록(MyClass) 내에서만 사용 가능
    func display() {}  //internal이 앞에 기본으로 들어가있다. 하나의 모듈 내부에서만 접근 가능
}

import Foundation

//옵셔널 타입은 변수, 상수에 아무런 값이 할당되지 않는 상황에서 안전하게 처리하기 위한 방법.
    //optional 타입은 연살할때 바로 사용할 수 없고 풀어줘야 된다.
    //자료형(Int, Double, ...)뒤에 ?, ! 가 쓰임. (자료형 값을 저장 or 값이 없음(nil))
    //옵셔널형 선언 : 자료형 뒤 ?, 옵셔녈 언래핑 : 변수명 뒤 !
    //옵셔널 타입만이 값이 없는 nil값을 가질 수 있다.(nil값을 저장할 수 있는 자료형)
//var myInt = nil  //에러, nil 값을 옵셔널이 아닌 변수,상수에 할당 불가
var myInt1 : Int? = nil  //사용가능
var myInt2 : Int?  //초기화 값이 자동으로 nil, 위랑 같은 말

print(Int("100"))  //Optional(100)
print(Int("100")!)  //100, 뒤의 "!"는 강제로 풀어헤침(force unwrapping) 옵셔널 값을 풀어준다는 의미.
print(Int("Hi"))  //nil(값이 없다)
//print(Int("Hi")!)  //"Hi"를 풀어주면 에러가 난다. "Hi" 값은 Int형이 아니므로

    //옵셔널 타입 변수를 선언 하기 (자료형 뒤에 "?" 사용)
var index : Int?  //index 변수는 정수 값을 갖거나, 아무 값도 갖지 않을 수 있음(nil).

var x : Int?  //초기값은 nil이다 (var x : Int? = nil)
x = 10
print(x)  //Optional(10),
//print(x!)  //10, force unwrapping, 만약 x값이 없으면 출력 시 에러(초기값이 nil이라 풀수가 없다.)

//강제 언래핑은 if문을 써줘야 된다(에러가 날 경우를 대비)
var y : Int?
y = 20
if y != nil {
    print(y!)
} else {
    print("nil")
}  //20, y가 nil이 아니면 y의 언래핑 값을 출력, 만약 nil이면 프린트"nil", ("!=" ~가 아니면)

//옵셔널 바인딩 - 옵셔널에 할당된 값을 임시 변수, 상수에 할당(if (var,let), while, guard)
//  if let "변수,상수" = 옵셔널 값의 변수 이름 {
//      옵셔널 변수 값(Optional(값))이 있으면 언래핑이 되서 변수, 상수에 대입하고 if문 실행 트루 값 출력
//      값이 없으면 if문의 조건이 거짓 값 출력
//  }
//  if let name: Type = OptionalExpression(옵셔널 방정식) {
//      Statements
//  }
var z : Int? = 30  //Optional(30)
if let zz = z {  //z의 초기값이 있으므로 "z"를 "zz"로 넘어갈 때 언래핑이 된다, 30
    print(zz)
} else {
    print("nil")
}  //30

//여러 옵셔널 변수 한번에 언래핑 하는 법 (, let 사용(콤마 let))
var pet1 : String? = "cat"
var pet2 : String? = "dog"
if let firstPet = pet1, let secondPet = pet2 {
    print(firstPet, secondPet)
} else {
    print("nil")
}




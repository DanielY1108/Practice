import Foundation

let weight = 68.0
let height = 183.0
let bmi = weight / (height * height * 0.0001)  //BMI (kg/m2)를 구하는 방법은 (몸무게) / (키)^2
let ShortBmi = String(format: "%.1f", bmi)  //소수점 줄이기

var body = ""

if bmi >= 40 {
    body = "초고도비만"
} else if bmi < 40 && bmi >= 35 {
    body = "고도비만"
} else if bmi < 35 && bmi >= 30 {
    body = "비만"
} else if bmi < 30 && bmi >= 25 {
    body = "과체중"
} else if bmi < 25 && bmi >= 18.5 {
    body = "정상체중"
} else if bmi < 18.5 {
    body = "저체중"
}
print("BMI : \(ShortBmi), 판정 : \(body)")

//함수로 만들어 보기
func calBmi(weight: Double, height: Double) -> String {
    let bmi = weight / (height * height * 0.0001)  //BMI (kg/m2)를 구하는 방법은 (몸무게) / (키)^2
    let ShortBmi = String(format: "%.1f", bmi)  //소수점 줄이기
    var body = ""
    
    if bmi >= 40 {
        body = "초고도비만"
    } else if bmi < 40 && bmi >= 35 {
        body = "고도비만"
    } else if bmi < 35 && bmi >= 30 {
        body = "비만"
    } else if bmi < 30 && bmi >= 25 {
        body = "과체중"
    } else if bmi < 25 && bmi >= 18.5 {
        body = "정상체중"
    } else if bmi < 18.5 {
        body = "저체중"
    }
    return "BMI : \(ShortBmi), 판정 : \(body)"
}
print(calBmi(weight: 80, height: 183))

//if ~ else를 switch ~ case로 바꿔보기
func calBmi1(weight: Double, height: Double) {
    let bmi = weight / (height * height * 0.0001)  //BMI (kg/m2)를 구하는 방법은 (몸무게) / (키)^2
    let ShortBmi = String(format: "%.1f", bmi)  //소수점 줄이기
    
    switch bmi {
    case 0..<18.5 :
        print("BMI : \(ShortBmi), 판정 : 저체중")
    case 18.5..<25 :
        print("BMI : \(ShortBmi), 판정 : 정상")
    case 25..<30 :
        print("BMI : \(ShortBmi), 판정 : 비만")
    case 30..<35 :
        print("BMI : \(ShortBmi), 판정 : 고도비만")
    default :
        print("BMI : \(ShortBmi), 판정 : 초고도비만")
    }
}
calBmi1(weight: 81, height: 175)

//클래스 구현
class BMI {
    var weight = 0.0
    var height = 0.0
    init(weight: Double, height: Double) {
        self.weight = weight
        self.height = height
    }
    func CalBmi() -> Double {
        return weight / (height * height * 0.0001)
    }
}
var kim : BMI = BMI(weight: 85, height: 180)
print(kim.CalBmi())

//BMI 결과 판정하는 클래스 만들어보기
class BMI1 {
    var weight = 0.0
    var height = 0.0
    init(weight: Double, height: Double) {
        self.weight = weight
        self.height = height
    }
    func calBmi() -> String {
        let bmi = weight / (height * height * 0.0001)  //BMI (kg/m2)를 구하는 방법은 (몸무게) / (키)^2
        let ShortBmi = String(format: "%.1f", bmi)  //소수점 줄이기
        var body = ""
        
        if bmi >= 40 {
            body = "초고도비만"
        } else if bmi < 40 && bmi >= 35 {
            body = "고도비만"
        } else if bmi < 35 && bmi >= 30 {
            body = "비만"
        } else if bmi < 30 && bmi >= 25 {
            body = "과체중"
        } else if bmi < 25 && bmi >= 18.5 {
            body = "정상체중"
        } else if bmi < 18.5 {
            body = "저체중"
        }
        return "BMI : \(ShortBmi), 판정 : \(body)"
    }
}
var yang : BMI1 = BMI1(weight: 90, height: 172)
print(yang.calBmi())

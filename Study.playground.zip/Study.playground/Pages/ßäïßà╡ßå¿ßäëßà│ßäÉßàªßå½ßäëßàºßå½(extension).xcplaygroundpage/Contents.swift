import Foundation

//클래스(상속 가능), 구조체(상속 불가), 열거형(상속 불가), protocol에 새로운 기능을 추가
//익스텐션은 하위 클래스(자식클래스)를 생성하거나 참조하지 않고(상속하지 않는다) 기존 클래스에 메서드 생성자, 계산 프로퍼티 등의 기능을 추가 하기 위해서 사용
//built - in 클래스(이미 만들어진 클래스), IOS 프레임워크에 내장된 클래스에 기능을 추가할 때, 익스텐션 사용하면 매우 효과적.
//클래스(구조체, 열거형, 프로토콜)은 다음과 같은 형태로 확장된다.

//extension 기존타입이름 {
//    //새로운 기능
//}

extension Double {
    var squared: Double {
        return self + self
    }
}
let myValue: Double = 3.0  //let myValue = 3.0
print(myValue.squared)
print(4.0.squared)  //상수를 넣어서 바로 뽑을 수도 있다.

import Foundation

//init은 stored propery의 초기값을 세팅하는 용도!, 인스턴스 초기화 하기
//클래스, 구초체, 열거형(enum) 인스턴스가 생성되는 시점에서 해야할 초기화 작업
//인스턴스가 만들어지면 자동으로 호출됨


//init 메서드(생성자)

class Man {
    //var age : Int = 1
    var age : Int                   //init이 있으면 초기값을 안넣어 줘도 된다.
    var weight : Double             //init을 안넣으면 디폴드 생성자(default init)가 생성됨
    func display() {
        print("나이는 \(age), 몸무게는 \(weight)")
    }
    init(yourAge : Int, yourWeight : Double){
        age = yourAge         //self.age = yourAge 같은 말 이지만 매개변수 이름이 다르기 때문에 (self.)생략 가능
        weight = yourWeight
    }   //designated initializer(데지그네이티드 생성자, 지정된) - 모든 프로퍼티(age, weight)를 다 초기화시키는 생성자
}
//var yang : Man = Man() - 여기서 init을 하나라도 직접 만들면 default initializer는 사라진다.
var yang : Man = Man(yourAge: 2, yourWeight: 4.5)
yang.display()


//self - 현재 클래스 내의 메서드나 프로퍼티를 가리킬 때 메서드나 프로퍼티 앞에 "self."을 붙인다.

class Man1 {
    var age : Int
    var weight : Double
    func display() {
        print("나이는 \(age), 몸무게는 \(weight)")
    }
    init(age : Int, weight : Double) {
        self.age = age          //self.age 는 클래스 안에 있는 인스턴스 메서드나 프로퍼티를 가르킴("= age"는 init의 변수를 가르킴)
        self.weight = weight
    }
}
var yang1 : Man1 = Man1(age: 10, weight: 15.5)
yang.display()

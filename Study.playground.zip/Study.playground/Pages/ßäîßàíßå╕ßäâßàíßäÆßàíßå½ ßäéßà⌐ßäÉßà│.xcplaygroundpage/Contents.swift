
import Foundation

struct User {
    let name: String
    let age: Int
    let company: String
}
class Test {
    let testValue = 10
    let text = "반갑습니다."
    
    init() {
        hello()
    }
    func hello(){
        let hello = "안녕하세요."
    }
}
class MemoryExam {
    let nickname = "shark"
    let count = 10
    let cheolSuUser = User(name: "철수", age: 15, company: "구글")
    let test = Test()
    
    init() {
        run()
    }
    func run() {
        let youngHeeUser = User(name: "영희", age: 30, company: "애플")
        let copyCheolSuUser = cheolSuUser
        let copyTest = test
    }
}
func main() {
    let memoryExam = MemoryExam()
}
main()




//MARK: - 다른 클래스의 프로퍼티를 사용하고 싶은때

class AA {
    var aa = 5  //aa를 초기화 시킨 뒤, reference후 프로퍼티로 접근

    static var bb = 10  //2. static 프로퍼티 이용
}

class BB {
    
    func myMethod() {
        
        let firstObject: AA = .init()  // =AA.init()
        firstObject.aa = 10
               print(firstObject.aa) // 1
        
        AA.bb= 20
        print(AA.bb)

    }
}
var num: BB = .init()  //BB.init()
num.myMethod()



import UIKit

//클로저 (익명 함수) - 이름이 없다.

//일반 함수로 하는방법 (클로저 아님)
func add(x: Int, y: Int) -> Int {
    return x+y
}
print(add(x : 10, y : 20))

//클로저 표현식(익명 함수) 사용
let add1 = {(x: Int, y: Int) -> Int in  //매개변수 앞에 "{" 넣어주고 기존 있던 "{" 자리에 "in" 을 입력.
    return(x+y)
}
print(add1(10, 20)) //호출시 그냥 매개변수 값만 넘겨주면 된다. (상수를 함수처럼 호출, 하지만 함수는 아니다)


//question (클로저 표현식으로 바꿔라)
func mul(val1 : Int, var2 : Int) -> Int {
    return val1 * var2
}
var result = mul(val1: 10, var2: 20)
print(result)

//answer
let mul = {(val1 : Int, val2 : Int) -> Int in  //여기서 mul1의 자료형은 (Int, Int) -> Int
    return val1 * val2
}
var result1 = mul(10,20)   //상수를 함수처럼 호출
print(result1)

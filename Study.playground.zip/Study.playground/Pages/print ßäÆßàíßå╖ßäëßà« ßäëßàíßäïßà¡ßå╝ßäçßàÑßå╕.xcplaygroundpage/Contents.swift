import Foundation

//print는 함수이다.

print(1.0, 2.0, 3.0, 4.0, 5.0)
print(1.0, 2.0, 3.0, 4.0, 5.0, separator : "...")  //1.0...2.0...3.0...4.0...5.0
for n in 0...5 {
    print(n, terminator: " ")  //0 1 2 3 4 5
}

//terminator - " " 밑으로 안내리고(열 제거후) 합쳐 준다. 모든 항목이 인쇄 된 후
//separator - " " 만큼 나눠 준다. "이 안쪽의" 사이 사이를 뭘로 채울건가.

import Foundation

//매개변수의 개수와 자료형이 다른 같은 이름의 함수를 여러개 정의
//하나의 클래스 안에 같은 이름의 함수를 여러개를 써서 구현.

//생성자(init)을 여러개 쓰는 방법
class Man {
    var age : Int = 0
    var weight : Double = 0
    func display() {
        print("나이 = \(age), 몸무게 = \(weight)")
    }
    init(age : Int ,weight : Double) {      //designated initializer
        self.age = age
        self.weight = weight
    }
    init(age : Int) {
        self.age = age
    }
}
var kim : Man = Man(age: 10, weight: 20)
kim.display()
var kim1 : Man = Man(age: 15)       //나이만 15로 초기화
kim1.display()
//var kim2 : Man = Man()        //init값이 없을 경우 디폴드 init 값이 초기값으로 들어감
//kim2.display()

import Foundation

    //함수 - 특정 작업을 수행하는 코드 블록
//보통 읽으면 문장이 된다!
//매개변수(parameter)와 인수(argument, actual parameter)는 서로 차이가 조금 있음
//함수 정의부의 값을 매개변수(parameter) - argument값을 받는다,
//호출할때 사용하는 것이 인수(argument)
//ex. 자판기가 있다. 동전 - 전달인자(argument), 자판기 속의 동전 - 매개변수(parameter), 물건이 나오면(return value)

    //메서드(method)
//특정 클래스(class), 구조체(struct), 열거형(enum) 내의 함수.
//함수(func)를 클래스 내에 선언하면 메서드라 부른다!!!

    //함수를 선언하는 방법
//func <함수명>(<매개변수 이름> : <매개변수 타입> , <매개변수 이름> : <매개변수 타입>, ...) -> <반환값 타입> {
//    //함수 코드
//}
func sayHello() {  //리턴 값이 없으면 자동으로 (-> Void) 생성, 지정하지 않아도 됨
  print("Hello")
}
sayHello()  //호출

func messege(name : String, age : Int) -> String {
    return("이름 : \(name), 나이 : \(age)")
}
var info = messege(name: "Daniel", age: 32)  //messege의 값을 info에 넣어라
print(info)

    //내부 매개변수 이름과 외부 매개변수 이름
func add(first x : Int, second y : Int) -> Int {  //외부(first) 내부(x) : 자료형(Int), 외부(second) 내부(y) : 자료형(Int) -> 리턴형
    return(x+y)  //함수 내부에서 정의 할때는 내부 매개변수명을 사용
}
var sum = add(first: 10, second: 20)  //함수 바깥쪽에서 호출할 때에는 외부 매개변수를 사용해야된다. add(x: 10, y: 20) 은 오류
print(sum)
//함수에서 외부 매개변수를 생략하면 내부 매개변수가 외부 매개변수 까지 겸함

func add1(_ x : Int, with y : Int) -> Int {  //첫번째 외부 매개변수만 생략하는 경우 많음 ( _ ) 사용
  return(x+y)
}
print(type(of: add1))  //(Int, Int) -> Int
let x = add1(10, with: 20)
print(x)

    //디폴트 매개 변수(argument) 정의하기
func hello (age : Int, name : String = "길동") -> String {  //초기 값을 "길동" 주면
  return("\(name)의 나이는 \(age)")
}
var messege = hello(age: 32)  //만약 Int값만 넘기면 자동으로 초기값 매개변수(길동)으로 설정
print(messege)  //길동의 나이는 32
var messege1 = hello(age: 51, name: "나라")  // 초기값 매개변수 대신 나라라는 argument 사용
print(messege1)  //나라의 나이는 51

    //함수로 부터 여러 개의 결과 반환
func convertor(length : Float) -> (meter : Float, yard : Float, centimeter : Float) { //리턴값을 튜플로 만들 수 있다.(이름 : 자료형,..)
  let meter = length * 0.0254     //리턴값을 지정해 주고
  let yard = length * 0.0277778
  let centimeter = length * 2.54
  return(meter, yard, centimeter)
}
var y = convertor(length: 20)  //변수(var)를 만들어서 argument를 만듬
print(y.meter)  //튜플 불러오기 (y.meter)
print(y.yard)
print(y.centimeter)

    //Question - 2개의 정수를 입력받아 가감제 리턴(소수점 몇자리 까지 출력)
func sss(num1 : Int, num2 : Int) -> (sum : Int, sub : Int, div : Double) {
    let sum = num1 + num2
    let sub = num1 * num2
    let div = Double(num1) / Double(num2)  //같은 자료형만 연산 가능
    return(sum, sub, div)
}
var result = sss(num1: 10, num2: 3)
print(result.sum)  //튜플로 값 생성
print(result.sub)
print(result.div)
//반올림 하는 2가지 방법[round, String(format:)]
print(round(result.div*100)/100)  //round() - 반올림 해주는 함수. (반올림하기전 * 100)/100 값이 나온후 나누기 100 = 소수점 2째 자리까지 출력
print(String(format: "%.2f", result.div))  //sting(format:) - 소수점 2자리까지 남기겠다 "%.2f" 사용
//참고 : https://stackoverflow.com/questions/27338573/rounding-a-double-value-to-x-number-of-decimal-places-in-swift

    //가변 매개변수
//함수가 지정된 데이터 타입으로 0개 또는 여러개의 매개변수를 받는 다는걸 표현 하기 위해 세 개의 점(...)을 이용해 선언
func shcoolName(schools : String...) {  //매개변수 뒤 자료형뒤에 ... 을 넣어주면 갯수는 0~무한대 설정 가능
    for name in schools {  //for <반복문에 사용할 이름값> in <매개변수>, name을 schools의 개수만큼 반복하겠다.
        print(name)
  }
}
shcoolName(schools: "미래중학교", "한국남고등학교", "인중고등학교", "라면대학교")

    //Question - 임의의 개수의 정수 값의 합을 출력하는 함수를 작성 후 호출
func totalSum(nums: Int ...) {
    var sum1 = 0  //누적시키는 값는 초기값 0을 주어야 한다.
    for sum2 in nums {
        sum1 = sum1 + sum2
    }
    print(sum1)  //for문 바깥쪽에다 써야 누적된 합 값이 나온다.
}
totalSum(nums: 1,2,3,4,5)

    //함수를 매개변수나 리턴값으로 사용
//스위프트 함수는 1급 객체(first class object)이다. 이 조건을 충족시 1급 객채라 한다. 함수를 데이터 타입처럼 처리 가능.
//1.변수(let, var)를 저장가능
//2.매개변수로 전달할 수 있다.
//3.리턴값으로 사용할 수 있다.
func inchesToFeet (inches : Float) -> Float {
    return inches * 0.083333
}
func inchesToYard (inches : Float) -> Float {
    return inches * 0.0277778
 }
let toFeet = inchesToFeet  //함수의 이름을 toFeet이란 상수에 저장.(함수를 자료형 처럼 보관 가능) 이 상수의 자료형은 함수과 같은 (Float) -> Float
let toYard = inchesToYard
var result1 = toFeet(10)  //함수이름 대신에 상수 이름으로 호출 가능. inchesToFeet(inches : 10)

func outputConversion(converterFunc: (Float) -> Float , value : Float) {  //함수를 매개변수(converterFunc)로 넣어주고 사용
    let result = converterFunc(value)
    print("Result - \(result)")
}
outputConversion(converterFunc: toFeet, value: 10)  //toFeet으로 변환하는 inchesToFeet 함수 호출
outputConversion(converterFunc: toYard, value: 10)  //toYard으로 변환하는 inchesToYard 함수 호출
//함수를 리턴형 값으로 할 수 있다.
func decideFunction (feet : Bool) -> (Float) -> Float {
    if feet {         //매개변수형         리턴형이 함수형
    return toFeet  //함수를 리턴
  } else {
    return toYard
  }
}
let z = decideFunction(feet: true)
print(z(10))

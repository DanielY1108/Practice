import Foundation

    //switch - case문
var value = 1
switch (value) {
case 0 :
    print("영")  //각 case문 마지막에 break가 숨어있다.
case 1 :
    print("일")
case 2 :
    print("이")
//case 3 :
    //에러, case문 뒤에 하나의 실행 문장이 있어야 에러가 안난다.
default :
    print("3이상")
}  //일

    //switch - case문 결합하기, 범위지정도 가능(case 0...9)
var month = 2
var days : Int?
switch (month) {
  case 1,3,5,7,8,10,12 :  //콤마사용해서 여러개 실행 가능
    print("31일 입니다.")
  case 4,6,9,11 :
    print("30일 입니다.")
  case 2 :
  print("28 or 29일 입니다")
  default :
    print("잘못 입력했어")
}

    //switch - case에서 where절 사용하기
//where절을 switch - case 에 부가적인 조건을 추가하기 위해 사용
//값이 속하는 범위뿐만 아니라 그 숫자가 짝수인지 홀수인지 까지도 검사 가능.
var weight = 65
switch (weight) {
  case 40...60  where weight % 2 == 0 :  // 40~60 사이에서 짝수 일때
    print("Thin")
  case 60...90 where weight % 2 == 0 :
    print("normal")
  case 90...120 where weight % 2 == 0 :
    print("fat")
  default :
    print("not human, 주의 : 홀수 입력함")
}

    //fallthrough
//만약에 case문에서  break에 걸리지 않고 내려가고 싶을때 사용
var num = 1
switch (num) {
case 0 :
    print("영")
case 1 :
    print("일")
    fallthrough
case 2 :
    print("이")
    fallthrough
case 3 :
    print("삼")
    fallthrough
default :
    print("4이상")
}
//일
//이
//삼
//4이상

    //Question - where절 사용 switch문 하나 만들기
var wakeUp = 7
var washFace = 10
switch wakeUp {
  case ...8 where (washFace - wakeUp) <= 1  :
  print("\(wakeUp)시에 일어나고 \(washFace)시에 씻는 부지런한 사람")
  default :
  print("\(wakeUp)시에 일어나고 \(washFace)시에 씻는 게으른 사람")
}


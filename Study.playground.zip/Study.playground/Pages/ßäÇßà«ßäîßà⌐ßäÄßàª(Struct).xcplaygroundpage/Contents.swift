import Foundation

//(구조체,enum)의 인스턴스는 값 타입, 클래스의 인스턴스는 참조타입
//구조체는 상속 불가, 상속을 할 필요가 없으면 구조체가 유리
//스위프트의 기본 데이터 타입은 모두 구조체이다(Int, String, Double, Array<Element>

struct Resolution {  //구조체 정의
    var width = 1024  //프로퍼티
    var height = 76
}
let myComputer = Resolution()  //인스턴스 생성
print(myComputer.height)  //프로퍼티 접근

//구조체 : Memberwise Initializer (init 메서드를 안써줘도 된다.)
struct Resolution1 {  //구조체 정의
    var width : Int  //프로퍼티
    var height : Int
}  //init메서드가 없지만
let myComputer1 = Resolution1(width: 100, height: 300)  //Memberwise Initializer(내부적으로 초기를 해준다) 자동으로 만들어진다.
print(myComputer1.height)

//클래스 내에 구조체
struct Resolution2 {
    var width = 1024
    var height = 768
}
class VideoMode {
    var resoltution = Resolution2()
    var frameRatae = 0.0
}
let myVideo = VideoMode()  //myVideo 인스턴스 생성
print(myVideo.resoltution.height)  // "." 를 여러번 찍어서 안쪽의 값을 뽑아준다

import Foundation

//Tuple이란 여러 값을 하나의 개체에 일시적으로 묶는 방법.
let myTuple = (10, 20.5, "Hi")  //어떠한 타입(Int, String, ...)도 넣을 수 있다.
print(myTuple.0)  //10, 맨 첫번째 값은 인덱스 0
print(myTuple.2)  //Hi
    
    //상수명을 여러개 써서 한 줄의 코드로 상수에 할당가능
let (myInt, myDouble, myString) = myTuple  //밑줄을 사용하면 그 값은 무시 ("_"), let (myInt, _, myString) = myTuple
print(myInt)  //10
    
    //각 값에 바로 이름을 할당도 가능
let myTuple1 = (count : 10, weight : 67.5, msg : "Hi" )
print(myTuple1.weight)  //67.5



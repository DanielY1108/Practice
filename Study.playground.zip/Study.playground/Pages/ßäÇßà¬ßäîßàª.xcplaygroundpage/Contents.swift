import Foundation

//다음과 같은 기능을 전체 하나의 소스로 작성하시오
//  bb()라는 메소드가 하나 있는 프로토콜 B를 만드시오
//  bb()메서드는 Int형 값을 매개변수로 받아 Int형으로 리턴하는 메서드이다.
//  클래스 A는 클래스 C라는 부모를 갖는다(C로부터 상속받는다)
//  클래스 A에서 프로토콜 B를 채택하고, 준수하는 소스를 작성하시오
//  bb()메서드는 Int형 값을 매개변수로 받아 두 배한 값을 Int형으로 리턴하는 메서드이다.
//  상속,overloading, overrideng, protocol이 모두 들어간 소스를 작성하여라!

protocol B {
    var x: Int {get set}
    func bb() -> Int
}
class C {
    var x: Int
    func bb(x: Int) -> Int {
        return x * 2
    }
    init(x: Int) {
        self.x = x
    }
}
class A: C {
    var y: Int = 1
    override func bb(x: Int) -> Int {
        return x * 2
    }
    init(x: Int, y: Int) {
        super.init(x: x)
        self.y = y
    }
}
var num = C(x: 1)
print(num.bb(x: 1))



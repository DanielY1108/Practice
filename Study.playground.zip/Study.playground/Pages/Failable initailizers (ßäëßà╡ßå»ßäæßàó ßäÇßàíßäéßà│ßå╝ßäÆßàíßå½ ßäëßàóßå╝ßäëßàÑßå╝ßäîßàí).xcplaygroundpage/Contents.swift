import Foundation

// init 다음에 "?" , "!" 쓰며 옵셔널 값이 리턴 된다.
// 오류 상황에 nil을 리턴하는 조건문이 있다 - "return nil"

class Man {
    var age : Int = 0
    var weight : Double = 0
    func display() {
        print("age = \(age), weight = \(weight)")
    }
    init?(age : Int, weight : Double) {
        if age <= 0 {
            return nil
        }
        else {
            self.age = age
        }
        self.weight = weight
    }
}
//1. 옵셔널 형으로 선언
var yang : Man? = Man(age: 1, weight: 20.5)
if let yang1 = yang {  //옵셔널 바인딩
    yang1.display()
}

//2. 인스턴스 생성과 동시에 옵셔널 바인딩(가장 많이 쓰임)
if let yang2 = Man(age: 2, weight: 30.5) {
    yang2.display()
}

//3.인스턴스를 생성하면서 바로 강제 언래핑(위험한 방법)
var yang3 : Man = Man(age: 3, weight: 40.5)!
yang3.display()

//4.옵셔널 인스턴스를 사용 강제 언래핑(위험한 방법)
var yang4 : Man? = Man(age: 4, weight: 50.5)
yang4!.display()

//question 나이나 몸무게가 음수이면 nil 반환하는 실패가능 생성자 구현
class Man1 {
    var age : Int = 0
    var weight : Double = 0
    func display() {
        print("age = \(age), weight = \(weight)")
    }
    init?(age : Int, weight : Double) {
        if age <= 0 || weight <= 0 {
            return nil
        } else {
            self.age = age
            self.weight = weight
        }
    }
}
var yang5 : Man1? = Man1(age : 5, weight : 60.5)
if let yang6 = yang5 {
    yang6.display()
}


import Foundation

//열거형(enum) - 관련있는 데이터들이 멤버로 구성되어 있는 자료형 객체(열거형이 하나의 자료형이 된다)
//    원치 않는 값이 잘못 입력되는 것 방지
//    입력 받을 값이 한정되어 있을 때
//    특정 값 중 하나만 선택하게 할 때
//색깔 - 빨강, 녹색, 파랑   성별 - 남, 여   등등

//열거형 정의
//  enum 열거형명 {
//      열거형 정의
//  }
enum Planet {
    case Mercury, Venus, Earth, Mars, Jupiter, Saurn, Uranus, Neptune
}  //하나의 case문에 멤버들 나열 가능
enum Compass {
    case North
    case South
    case East
    case West
}
print(Planet.Mars)
var direction = Compass.West  //var direction : Compass 가능
direction = .East  //위에 한번이라도 열거형명이 호출되면 다음부터는 생략가능
print(direction, type(of: direction))  //East Compass(자료형은 Compass)

switch direction {
case.North :
    print("북")
case.South :
    print("남")
case.East :
    print("동")
case.West :
    print("서")
}

//열거형 멤버에서 메서드도 가능
enum Week: String {
    case Mon,Tue, Wed, Thur, Fri, Sat, Sun
    func printWeek() {
        switch self {
        case .Mon, .Tue, .Wed, .Thur, .Fri :
            print("주중")
        case .Sat, .Sun :
            print("주말")
        }
    }
}
Week.Sun.printWeek()

//열거형의 rawValue
enum Color: Int {  //Hashable 프로토콜을 준수하는 기본자료형
    case red = 0
    case green
    case blue
}
print(Color.red)
print(Color.blue)
print(Color.red.rawValue)  //rawValue - red 내부적으로 어떤 값으로 저장이 되있는가
print(Color.blue.rawValue)

//String형의 열거형 rawValue
enum Weeks: String {
    case Monday = "월"
    case Tuseday = "화"
    case Wednesday = "수"
    case Thursday = "목"
    case Friday = "금"
    case Saturday
    case Sunday
}
print(Weeks.Monday)
print(Weeks.Monday.rawValue)  // "=" 뒤의 값이 출력됨
print(Weeks.Sunday)
print(Weeks.Sunday.rawValue)  //문자형 같은 경우는 저장이 안되있으면 case 이름이 할당 됨

//연관 값(associatred Value)을 갖는 Enum
enum Date {
    case intDate(Int, Int, Int)  //(Int, Int, Int)형 연관값을 갖는 intDate
    case stringDate(String)  //String형 연관값을 갖는 stringDate
}
var todayDate = Date.intDate(2022, 7, 24)  //위에 3개를 만들어 줬으니 int값을 3개 넣어야 된다
todayDate = Date.stringDate("2022년 8월 24일")
switch todayDate {
case .intDate(let Year, let Month, let day) :
    print("\(Year)년 \(Month)월 \(day)일")
case .stringDate(let date) :
    print(date)
}

//옵셔널은 연관 값(ssociatred Value)을 받는 enum
var x : Int? = 20  //Optional(20)
var y : Int? = Optional.some(10)  //Optional(10)
var z : Int? = Optional.none  //nil

let age : Int? = 30
switch age {
case .none:  //값이 nil인 경우
    print("나이 정보가 없습니다")
case .some(let a) where a < 20 :
    print("미성년자입니다")
case .some(let a) where a < 70 :
    print("성인입니다")
default :
    print("경로우대 입니다")
    
}

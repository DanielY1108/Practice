import Foundation

//저장 프로퍼티(stored property)와 계산 프로퍼티(computed property) - 기본은 저장 프로퍼티(stored property)
//타입 프로퍼티 - 새로운 인스턴스가 생성될 떄 마다 새로운 프로퍼티고 같이 생성 된다
//            인스턴스 프로퍼티와는 다르게 타입 프로퍼티는 항상 초기값을 지정해서 사용해야 합니다.
//            왜냐하면 타입 자체에는 초기자(Initializer)가 없어 초기화 할 곳이 없기 때문입니다.

//계산 프로퍼티는 프로퍼티가 설정되거나 검색되는 시점에서 계산 또는 파생된 값
//계산 프로퍼티 내에는 - 값을 리턴하는 게터(getter) 메서드, 값을 대입한는 세터(setter) 메서드

class Man {
    var age : Int = 1
    var weight : Double = 3.5
    var manAge : Int {          //메서드(함수) 같지만 computed property 이다.
        get {return age - 1}
        //{return age -1}     getter에서는 return값 생략 가능 ("get{ }" 생략). 만약 setter도 같이 쓰면 "get{ }" 생략 불가.
        set(USAAge) {age = USAAge + 1}  //setter는 밑에 매개변수를 받아야(kim.manAge = 5) 호출이 가능하다.
        //set(newValue) {age = newValue + 1}.  매개변수명은 newValue가 기본 값이다. set(newValue)
        //set {age = newValute + 1}.  매개변수가 newValue일때 set 뒤의 "(newvalue)" 생략 가능.
    }
    func display() {
        print("나이 = \(age), 몸무게 = \(weight)")
    }
    init(age : Int, weight : Double) {
        self.age = age
        self.weight = weight
    }
}
var kim : Man = Man(age: 10, weight: 60.5)
kim.display()
print(kim.manAge)       //9, getter 호출
print(kim.age)          //10,
kim.manAge = 5          //setter 호출, 값을 대입하기 때문에 set을 호출하게 된다.
print(kim.age)          //6 setter 값
kim.display()

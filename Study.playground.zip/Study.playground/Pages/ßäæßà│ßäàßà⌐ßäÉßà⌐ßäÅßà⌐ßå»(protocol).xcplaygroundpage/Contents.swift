import Foundation

//프로토콜 - 특정 클래스와 관련없는 프로퍼티, 메서드 선언 집합
//  함수(메서드) 정의는 없음
//  기능이나 속성에 대한 설계도
//  클래스(구조체, 열거형)에서 채택(adopt)하여 메서드를 구현해야 함.
 
//class 자식 : 부모 {
//}  부모 클래스는 하나만 가능, 콜론 다음이 여러 개라면 나머지는 프로토콜

//class 클래스명 : 부모명, 프로토콜명 {}  //부모가 있으면 부모 다음에 표기
//class 클래스명 : 부모명, 프로토콜명1, 프로토콜명2 {}
//class 클래스명 : 프로토콜명 {}  //부모가 없으면 바로 표기 가능
//class 클래스명 : 프로토콜명1, 프로토콜명2 {}
//상속은 클래스만 가능.
//프로토콜은 채택(adopt)할 수 있다. - 클래스, 구조체(struct), 열거형(enum), extension 채택 가능.

//프로토콜의 정의
//protocol 프로토콜명 {
//    프로퍼티명
//    메서드 선언 //메서드는 선언만 있다
//}
//protocol 프로토콜명 : 다른프로토콜, 다른프로토콜2 {
//    프로토콜은 다중 상속도 가능
//}

//프로토콜과 프로퍼티/메서드 선언
protocol SomeProtocol {
    //프로퍼티
    var x: Int { get set }  //읽기와 쓰기가 가능, 선언만 되어있으면 된다 초기화를 안해줘도 된다(init, 초기값)
    var y: Int { get }  //읽기 전용
    static var tx: Int { get set }  //상속 고려하지 않으면 static 사용
    //메서드
    static func typeMethod()  //static이 있으면 타입 메소드(프로토콜 자체가 동작), {} 안쪽의 기능을 넣지 않는다.
    func random() -> Double
}

//예제
protocol Runable {
    var x: Int {get set}  //선언
    func run()  //리턴 값 없고, 매개변수 없다.
}
class Man : Runable {  //이 한줄 갖고는 부모인지 프로토콜인지 알 수 없다. 이전 코드 참고를 해야된다.  채택한다, adopt
    var x : Int = 1  //준수, conform
    func run() {  //준수, conform
        print("달린다")
    }
}
let kim = Man()
print(kim.x)
kim.run()

//Delegate, dataource는 100% 다 프로토콜이다.

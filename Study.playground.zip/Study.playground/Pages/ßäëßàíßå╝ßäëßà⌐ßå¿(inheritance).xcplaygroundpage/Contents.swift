import Foundation

//상속된 클래스는 부모 클래스의 모든 기능을 상속 받으며, 자신만의 기능을 추가 - 하위 클래스, 자식 클래스라 부른다.
//하위(자식) 클래스가 상속 받은 클래스는 - 상위 클래스, 부모 클래스라 부른다.
//스위프트는 하위(자식) 클래스는 단 하나의 부모 클래스만 상속가능(단일 상속)

//상속
//class 자식 : 부모 {
//}  부모 클래스는 하나만 가능, 콜론 다음이 여러 개이면 나머지는 프로토콜

//상속의 단점
//오버라이딩을 할 메서드의 캡슐화가 전체적으로 깨질 수 밖에 없습니다.
//코드를 중복해서 사용할 가능성이 있다.
//등등 참고 : https://kirkim.github.io/swift/2022/08/05/inheritance_protocol.html
 
//class 클래스명 : 부모명, 프로토콜명 {}  //부모가 있으면 부모 다음에 표기
//class 클래스명 : 부모명, 프로토콜명1, 프로토콜명2 {}
//class 클래스명 : 프로토콜명 {}  //부모가 없으면 바로 표기 가능
//class 클래스명 : 프로토콜명1, 프로토콜명2 {}
//상속은 클래스만 가능.
//프로토콜은 채택(adopt)할 수 있다. - 클래스, 구조체(struct), 열거형(enum), extension 채택 가능.

class Man {
    var age : Int = 0
    var weight : Double = 0
    func display() {
        print("나이 = \(age), 몸무게 = \(weight)")
    }
    init(age : Int ,weight : Double) {      //designated initializer
        self.age = age
        self.weight = weight
    }
}
var yang : Man = Man(age: 10, weight: 20)  //생성자로 초기화를 했기 때문에 값 넣어야 된다.
yang.display()

//위의 부모 클래스로부터 자식 클래스로 상속 받고 싶을때
class Student : Man {
    //비어있지만 Man의 모든 것을 가지고 있음
}
var kim : Student = Student(age: 20, weight: 30)  //var kim = Student(age: 20, weight: 30) 생략 가능
kim.display()
print(kim.age)

//super : 부모 메서드(함수) 호출 시 사용
class Human {
    var age: Int = 0
    var weight: Double = 0
    func display() {
        print("나이 = \(age), 몸무게 = \(weight)")
    }
    init(age: Int ,weight: Double) {
        self.age = age
        self.weight = weight
    }
}
//나이와 무게는 부모껄 상속 받아 쓰지만 이름을 추가하고 싶을때(super)
class nameOfHuman : Human {
    var name : String = "JinSeok"  //저장 프로퍼티 생성
    func displayS() {
        print("이름 = \(name), 나이 = \(age), 몸무게 = \(weight)")
    }
    init(age: Int, weight: Double, name: String) {
        super.init(age: age, weight: weight)  //자식쪽에서 부모 생성자 호출시 "super." 필수, 부모쪽의 생성자도 호출되기 때문에(부모쪽의 프로퍼티를 가져옴)
        self.name = name  //새로운 이름에 대한 생성자
//    init(age1: Int, weight1: Double, name: String) {  //만약 호출할 때 헷갈리면 이름을 바꿔줘도 됨(age1을 부모클래스의 age로 넘겨준다.)
//        super.init(age: age1, weight: weight1)
//        self.name = name
    }
}
var lee /* : nameOfHuman */ = nameOfHuman(age: 30, weight: 60, name: "jin")
//var lee : nameOfHuman = nameOfHuman(age1: 30, weight1: 60, name: "jin")
lee.displayS()  //자식쪽의 함수 호출
lee.display()  //부모쪽의 함수 호출(상속이 되도 사용가능)
